      coeffs_dx->coeff_0_0 = y+RATIONAL(-1.0,1.0);
      coeffs_dx->coeff_p1_0 = -y+RATIONAL(1.0,1.0);
      coeffs_dx->coeff_0_p1 = -y;
      coeffs_dx->coeff_p1_p1 = y;
