/*@@
  @header   HAMADM_undefine.h
  @date     Aug 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef HAMADM_GUTS

#include "TRRICCI_undefine.h"
#include "TRKK_undefine.h"
#include "TRK_undefine.h"





