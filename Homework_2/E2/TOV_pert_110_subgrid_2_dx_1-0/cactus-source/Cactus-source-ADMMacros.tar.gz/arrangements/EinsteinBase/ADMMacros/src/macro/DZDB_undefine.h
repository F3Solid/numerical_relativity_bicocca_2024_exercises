/*@@
  @header   DZDB_undefine.h
  @date     Jun 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DZDB_GUTS

