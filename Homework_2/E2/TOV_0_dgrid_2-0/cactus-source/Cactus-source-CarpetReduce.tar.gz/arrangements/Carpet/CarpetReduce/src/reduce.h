#ifndef CARPETREDUCE_H
#define CARPETREDUCE_H

#ifdef __cplusplus
namespace CarpetReduce {
extern "C" {
#endif

/* Scheduled functions */
int CarpetReduceStartup(void);

#ifdef __cplusplus
} /* extern "C" */
} /* namespace CarpetReduce */
#endif

#endif /* !defined(CARPETREDUCE_H) */
