/* Stuff from extra packages */
#ifndef _CCTK_EXTRADEFS_H_
#define _CCTK_EXTRADEFS_H_

/* BLAS definitions */

/* FFTW definitions */

/* GRACE definitions */

/* HDF5 definitions */

/* LAPACK definitions */

/* LORENE definitions */

/* MPI definitions */

/* PETSC definitions */

/* PTHREADS definitions */

#endif /*_CCTK_EXTRADEFS_H*/
